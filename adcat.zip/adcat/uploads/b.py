import socket,sys
def find(k):
    c=["fox","Waste"]
    for i in c:
        if i in k:
            return 1
    return 0        
s=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
host=''
port=10000
print(sys.stderr,"starting up on %s port %s" %(host,port))
s.bind((host,port))
e="Claim is done"
e=e.encode('utf-8')
e1="Claim is fake"
e1=e1.encode('utf-8')
while True:
    data,address=s.recvfrom(4096)
    data=data.decode('utf-8')
    if find(data) is 1:
        sent=s.sendto(e,address)
    else:
        sent=s.sendto(e1,address)
        
