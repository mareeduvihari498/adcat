import os
from PIL import Image
import pytesseract
def send(s):
    c=s.strip()
    os.system('python b.py')
    import socket,sys
    s=socket.socket(socket.AF_INET,socket.SOCK_DGRAM)
    saddress=('localhost',10000)
    msg=c
    msg=c.encode('utf-8')
    try:
        
        sent=s.sendto(msg,saddress)
        data,server=s.recvfrom(4096)
        htl(data)
    finally:
        s.close()
def htl(k):
    c=os.getcwd()
    c.replace('uploads','index1.html')
    html_str =k.decode('utf-8')
    Html_file= open("c","w")
    Html_file.write(html_str)
    Html_file.close()
while True:
    for fname in os.listdir('.'):
        if fname.endswith('.png') or fname.endswith('.jpg') or fname.endswith('.gif'):
            pytesseract.pytesseract.tesseract_cmd = os.getcwd()+'\\tesseract.exe'
            c=os.getcwd()+'\\'+fname
            text = pytesseract.image_to_string(Image.open(c))
            send(text)
        
